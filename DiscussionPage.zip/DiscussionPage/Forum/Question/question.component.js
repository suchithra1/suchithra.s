import React from 'react';
import { Checkbox } from '@material-ui/core';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Input from '@material-ui/core/Input';
import ListItemText from '@material-ui/core/ListItemText';
import NativeSelect from '@material-ui/core/NativeSelect';
import Select from '@material-ui/core/Select';
import Button from '@material-ui/core/Button';
import classes from './question.scss';


const names = ['Java','react','angular'];

const question = (props) => {
    console.log(JSON.stringify(props))
    return (
        <div className={classes.question}>
        <div className={classes.topic}>
        <div className ={classes.primaryTopic}>
       
            <NativeSelect  value={props.primeTopic}
                           name='primaryTopic'
                           onChange={props.inputChange}
                           >
                <option value='' disabled> Primary </option>
                <option value='Java'>Java</option>
                <option value='React'>React</option>
          
            </NativeSelect>
        </div>
        <div className ={classes.secondaryTopic}>
        <Select multiple
          displayEmpty
          value={props.secondTopic}
          onChange={props.inputChange} 
          name='secondaryTopic'
          input={<Input id="select-multiple-checkbox" />}
          renderValue={selected => {
            if (selected.length === 0) {
              return <em>Secondary</em>;
            }

            return selected.join(', ');
          }}
         
        >
         <MenuItem disabled value="">
            <em>Secondary</em>
          </MenuItem>
          {names.map(name => (
            <MenuItem key={name} value={name}>
              <Checkbox checked={props.secondTopic.indexOf(name) > -1} />
              <ListItemText primary={name} />
            </MenuItem>
          ))}
        </Select>

        
        </div>
        </div>
        <div className={classes.titleDescription}>
        
        {/* <TextField   placeholder='Enter title' margin='normal' variant='outlined' className='text'  /> */}
            <input type='text' 
                        className = {classes.questionTitle}
                               placeholder='Enter Title' 
                               name='title'
                               value = {props.questionTitle}
                               onChange={props.inputChange}
                               />  
       

        
        {/* <TextField   placeholder='Enter description' margin='normal' variant='outlined' /> */}
            <input type='text' 
            className ={classes.questionDescription}
                               placeholder='Enter description'
                               name='description'
                               value = {props.questionDescription}
                               onChange={props.inputChange}
                               />  
        
        <div className={classes.questionButton}>
            <div className={classes.cancelButton}>
                <Button variant='outlined' margin='normal'  onClick={props.cancel} >  Cancel  </Button>
            </div>
            <div className={classes.postButton}>
                <Button variant='contained' color='primary' onClick={props.post}
                        disabled={!(props.questionTitle && props.questionDescription)} 
                        >  Post Question  </Button>
            </div>
            </div>
       </div>
       </div>

    );
}

export default question;