import React from 'react';
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import TextField from '@material-ui/core/TextField';
import { Checkbox } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import classes from './question.scss';




const question = (props) => {
    console.log(JSON.stringify(props))
    return (
        <div className={classes.question}>
        <div className ={classes.primaryTopic}>
        <ReactMultiSelectCheckboxes placeholderButtonLabel = 'primary' 
                                    minWidth = '120px'
                                    // options = {props.courses}
                                    // name = {roleToDisplay.name}
                                    // key = {index}
                                    // onChange = {props.courseSelected} 
                                    />

        
        </div>
        <div className ={classes.secondaryTopic}>
        <ReactMultiSelectCheckboxes placeholderButtonLabel = 'secondary' 
                                    minWidth = '120px'
                                    // options = {props.courses}
                                    // name = {roleToDisplay.name}
                                    // key = {index}
                                    // onChange = {props.courseSelected} 
                                    />

        
        </div>
        <div> 
            <input type='text' className = {classes.questionTitle}
                               placeholder='Enter Title' 
                               name='title'
                               value={props.questionTitle}
                               onChange={props.inputChange}
                               />  
        </div>

        <div> 
            <input type='text' className ={classes.questionDescription}
                               placeholder='Enter description'
                               name='description'
                            //    onChange={props.inputChange}
                               />  
        </div>
        {/* <div className={classes.questionButton}> */}
            <div className={classes.cancelButton}>
                <Button variant="contained" color="primary" onClick={props.cancel} >  Cancel  </Button>
            </div>
            <div className={classes.postButton}>
                <Button variant="contained" color="primary" onClick={props.post}  disabled={!props.questionTitle} >  Post Question  </Button>
            </div>
       {/* </div> */}
       </div>

    );
}

export default question;
