/*
 * File: discussion.component.spec.js
 * Project: land-react-ui
 * File Created: Wednesday, 27th March 2019 4:44:28 pm
 * Author: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Last Modified: Wednesday, 27th March 2019 4:44:28 pm
 * Modified By: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */
