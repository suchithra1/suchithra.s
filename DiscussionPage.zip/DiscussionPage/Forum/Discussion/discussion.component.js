import React from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import classes from './discussion.scss';

const discussion = (props) => {
    return(
        <div className={classes.discussion}> 
            <Card>
                <CardContent >
                    <div>
                        <div className={classes.title}>{props.data.title}</div>
                        <span className={classes.user}>{props.data.user.firstName}</span>
                        
                        <div className={classes.followButton}>
                        <Button variant='outlined' 
                                color='primary'>  Follow Response  </Button>
                        </div>
                        <div>{props.comment.comment}</div>
                    </div>
                    <div>
                        <div className={classes.comment}>
                             {discussion.comment}
                        </div>
                         <div className={classes.replyButton}>
                        <Button variant='contained' 
                                color='primary'
                                onClick = {props.reply}> Reply  </Button>
                        </div>
                    </div>  
                    <div>
                    {/* <TextField className={classes.answer}  defaultValue="Write your response"  margin="normal" variant="outlined" /> */}
                        <input className={classes.answer} type='text' placeholder='Write your response' autoFocus/>
                    <div className={classes.answerButton}>
                        <Button variant='contained' 
                                color='primary'> Add an answer  </Button>
                        </div></div>
                </CardContent>
                <CardActions/>
            </Card> 
        </div>

    );
}

export default discussion;
