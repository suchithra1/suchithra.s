import React from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import classes from './discussion.scss';

const discussion = (props) => {

    console.log(props.comment);
    return(
        <div className={classes.discussion}> 
        
        <Card>
                <CardContent >
                    <div>
                        <div className={classes.title}>{props.data.title}</div>
                        <span className={classes.user}>{props.data.user.firstName}</span>
                        
                        <div className={classes.followButton}>
                        <Button variant='outlined' 
                                color='primary' onClick={props.follow} >  {props.label}  </Button>
                        </div>
                    </div>
                    <div className={classes.commentReply}>
                        <div className={classes.comment}>
                        {props.comment[0].comment}
                        </div>
                         <div className={classes.replyButton}>
                         
                        <Button variant='contained' 
                                color='primary'
                                onClick = {props.reply(props.comment)}> Reply  </Button>
                        </div>
                    </div>  
                    <div className={classes.postAnswer}>
                    <TextField className={classes.answer}  placeholder={props.replyComment} value={props.responseComment}
                                margin="normal" variant="outlined" name='comment' onChange={props.inputChange}
                                autoFocus onfocus="this.value = this.value;"/>
                        {/* <input className='answer' type='text' placeholder='Write your response' autoFocus/> */}
                    <div className={classes.answerButton}>
                        <Button variant='contained' 
                                color='secondary' onClick={props.postComment}> Add an answer  </Button>
                        </div></div>
                </CardContent>
                <CardActions/>
            </Card> 

        </div>

    );
}

export default discussion;