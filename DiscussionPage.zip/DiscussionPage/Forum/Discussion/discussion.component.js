import React from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import {Route, Link, NavLink} from 'react-router-dom';
import TextField from '@material-ui/core/TextField';
import classes from './discussion.scss';


const discussion = (props) => {
    {props.comment.map((comment) => {
        console.log(comment.comment);
    } )}

    return(
        <div className={classes.discussion}> 
        <div>
            <header className={classes.link}> Back to All Questions </header>
        </div>
            <Card className={classes.discussionCard}>
                <CardContent >
                    <div>
                        <div className={classes.title}>{props.data.title}</div>
                        <span className={classes.user}>{props.data.user.firstName}</span>
                        
                        <div className={classes.followButton}>
                            <Button variant='outlined' 
                                    color='primary'>  Follow Response  </Button>
                        </div>
                    </div>
                    {/* {props.comment.map((comment) => { */}
                    <div className={classes.commentSection}>
                        <div className={classes.commentAuthor}>Induja</div>
                        <div className={classes.comment}>{props.comment[0].comment}</div>
                        <div className={classes.replyButton}>
                            <Button variant='contained' 
                                    color='primary'
                                    onClick = {props.reply}> Reply  </Button>
                        </div>
                    </div>
                     {/* })} */}
                    <div className={classes.answerField}>
                        <input className={classes.answer} type='text' placeholder={props.replyComment} autoFocus/>
                        <div className={classes.answerButton}>
                            <Button variant='contained' 
                                    color='primary'> Add an answer  </Button>
                        </div>
                                            
                                            

                    </div>
                </CardContent>
                <CardActions/>
            </Card> 
        </div>

    );
}

export default discussion;
