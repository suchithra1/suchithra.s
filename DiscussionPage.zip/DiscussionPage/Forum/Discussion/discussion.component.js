import React from 'react';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import classes from './discussion.scss';

const discussion = (props) => {
    return(
        <div className={classes.discussion}> 
        
            {props.data.map((discussion, index) => <Card>
                <CardContent key={index}>
                    <div>
                        {discussion.question}
                        <div className={classes.followButton}>
                        <Button variant="contained" 
                                color="primary">  Follow Response  </Button>
                        </div>
                    </div>
                    <div>
                        <div className={classes.comment}>
                             {discussion.comment}
                        </div>
                         <div className={classes.replyButton}>
                        <Button variant="contained" 
                                color="primary"
                                onClick = {props.reply}> Reply  </Button>
                        </div>
                    </div>  
                    <div><input className={classes.answer} type='text' placeholder='Write your response' autoFocus/>
                    <div className={classes.answerButton}>
                        <Button variant="contained" 
                                color="primary"> Add an answer  </Button>
                        </div></div>
                </CardContent>
                <CardActions/>
            </Card> )}
        </div>

    );
}

export default discussion;
