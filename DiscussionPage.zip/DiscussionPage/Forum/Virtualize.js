import React, {Component} from 'react';
import { List, AutoSizer } from "react-virtualized";
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import classes from './Forum.scss'

/*
 * File: Virtualize.js
 * Project: land-react-ui
 * File Created: Monday, 25th March 2019 6:46:12 pm
 * Author: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Last Modified: Wednesday, 27th March 2019 12:49:52 pm
 * Modified By: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */


class Virtualize extends Component {
    // state = {
    //     items : this.props.data,
    //     rowWidth : this.props.width
        
    // }
    
    // componentWillMount() {
    //     console.log('mount', this.props.data)
    //     this.setState({items: this.props.data,
    //         rowWidth : this.props.width})
    //     }
        
        // componentWillReceiveProps(nextProps) {
        //     this.setState({items: nextProps.data});
        // }
        
        renderRow = () => {
            console.log(this.props.data)
            console.log('rowrender')
            return (
                this.props.data.map((item, index) => 
                <Card  className ={classes.card}
                key = {index}
                onClick = {() => this.props.select(item.discussion)}>
                <CardContent>
                    <div className={classes.title}> {item.discussion.title}</div>  
                    <div>{item.discussion.description}</div>
                </CardContent>
                </Card> )
        );
    }
    
    render() {
        const rowCount = 1000; 
        const listHeight = 500;
        const rowHeight = 80;
      const rowWidth = 1350;
      console.log('render')  
    //   console.log(this.state.items.length)
      console.log(this.props.data)
    //   console.log(this.state.rowWidth)
      return (
              <List  width={rowWidth}
                     height={listHeight}
                     rowHeight={rowHeight}
                     rowRenderer={this.renderRow}
                     rowCount={this.props.data.length}
                     rowCount={25}
                     overscanRowCount={3} />
             
      );
    }
}

export default Virtualize;