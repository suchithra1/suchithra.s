import React, {Component} from 'react';
import { List } from "react-virtualized";
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import classes from './Virtualize.scss'

/*
 * File: Virtualize.js
 * Project: land-react-ui
 * File Created: Monday, 25th March 2019 6:46:12 pm
 * Author: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Last Modified: Tuesday, 26th March 2019 5:52:13 pm
 * Modified By: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

const rowCount = 1000; 
const listHeight = 400;
const rowHeight = 15;
const rowWidth = 955;

class Virtualize extends Component {
  constructor(props) {
    super(props);
    console.log(this.props.data)

    this.state = {
        items : [],
      
    }

    this.list = Array(rowCount).fill().map((val, idx) => {
      return {
        id: idx, 
        name: 'John Doe',
      }
    });

    // this.list = this.state.items.map((item) => {
    //   return {
    //     name: item.discussion,
    //   }
    // });
    
  }

  // componentWillReceiveProps(props) {
  //   console.log(props.data)
  //     this.setState({items: props.data})
  // }

  componentWillMount() {
      console.log('mount', this.props.data)
      this.setState({items: this.props.data})

  }

  componentDidUpdate() {
    console.log(this.props)
    this.setState({items: this.props.data})
  }
  
  renderRow = ({ index, style }) => {
    // console.log('render row called')
    return (
        <div>
              <Card  key={index}  className ={classes.card}>
                 <CardContent className={classes.card}>
              {/* <div>{this.list[index].name}</div> */}
             <div> {this.state.items}</div>  
              {/* <div>{JSON.stringify(props.data[0])}</div> */}
              </CardContent>
              </Card>
        </div>
        );
      }
  
  render() {
    console.log(this.state.items)
    // console.log(this.props);
    // console.log(rowCount);
    return (
        <div >
       <List  width={rowWidth}
              height={listHeight}
              rowHeight={rowHeight}
              rowRenderer={this.renderRow}
              rowCount={this.list.length}
              overscanRowCount={3} />
      </div>
  );
}

}

export default Virtualize;