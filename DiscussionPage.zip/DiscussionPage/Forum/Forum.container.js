import React, {Component} from 'react';
import classes from './Forum.scss';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import { Checkbox } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import Select from "@material-ui/core/Select";
import NativeSelect from '@material-ui/core/NativeSelect';
import MenuItem from "@material-ui/core/MenuItem";
import Question from './Question/question.component';
import Discussion from './Discussion/discussion.component';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


import Virtualize from './Virtualize'

/*
 * File: Forum.container.js
 * Project: land-react-ui
 * File Created: Wednesday, 20th March 2019 11:44:32 am
 * Author: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Last Modified: Wednesday, 27th March 2019 6:50:34 pm
 * Modified By: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

class Forum extends Component {
    state = {
        doLoadDiscussion: true,
        discussions:[],
        comments: [],
        topics: [],
        sortBy : '',
        selectedDiscussion : {},
        doAskQuestion: false,
        isDiscussionSelected: false,
        title:'',
        description:'',
        primaryTopic: '',
        secondaryTopic: [],
        reply: 'Write your response',
        selectedDiscussion : {},
        comment: '',
        responseLabel: 'Follow Response'
    }

    getTopic = () => {
        let data = require('../../assets/topic.json');
        this.setState({topics : data})
    }

    getComment = () => {
        let data = require('../../assets/comment.json');
        this.setState({comments : data});
    }

    componentDidMount = () => {
        this.getComment();
        this.getTopic();
        let data = require('../../assets/discussion.json');
        this.setState({discussions : data});
        console.log(data)
    }

    onSearch = (event) => {
        let searchText = event.target.value;
        let allDiscussions = [...this.state.discussions];
        let searchedDiscussion = [];
        allDiscussions.filter( (discussion) => {
            let question = discussion.discussion.description.toLowerCase();
              if( (question.includes(searchText.toLowerCase())) || (question.startsWith(searchText.toLowerCase()))) {
                   searchedDiscussion.push(discussion); 
                   
                }
            });

            if(searchText === 0) {
                this.setState({discussions: allDiscussions})
            } else {
                this.setState({discussions : searchedDiscussion}) 
            }

            console.log(searchedDiscussion); 
    }

    onSelectChange = (event) => {
        console.log(event.target.value)
    }

    onSelectDiscussion = (discussion) => {
        let discussionId = discussion.id;
        console.log(discussion);
        console.log(discussionId);
        // api call with discussionId - repsonse is comments

        this.setState({ isDiscussionSelected : true,
                        doLoadDiscussion :false,
                        selectedDiscussion : discussion
        })
        console.log(this.state.selectedDiscussion);            
        // this.onSetResponseLabel();          
    }

    onSetResponseLabel = () => {
        console.log(this.state.comments[0].followerId.id);
        let commentFollowerId = this.state.comments[0].followerId;
        let label = '';
        if(!(commentFollowerId === 'null')) {
            console.log('true')
            label = 'Following Response'
        } 
        this.setState({responseLabel: label}) 
        console.log(this.state.responseLabel);
    }

    onChange(event) {
        this.setState({[event.target.name]: event.target.value});
        console.log(this.state.name)
    }
    
    onAskQuestion = () => {
        console.log('ask question');
        this.setState({doAskQuestion: true,
                       doLoadDiscussion: false})
    }

    onCancelQuestion = () => {
        console.log('cancel');
        this.setState({ doAskQuestion :false,
                        doLoadDiscussion : true})
    }
    
    onPostQuestion = () => {
        let title = this.state.title;
        let description = this.state.description;
        let relatedTopic = [...this.state.secondaryTopic];
        let discussionTopics = [];
        
        let primeTopic = {};
            primeTopic.primary = 'true';
            primeTopic.topic = this.state.primaryTopic;
        discussionTopics.push(primeTopic);
        console.log(primeTopic);

        relatedTopic.map((topic, key) => {
            let nonPrimeTopic = {};
            // nonPrimeTopic.index = key;
            nonPrimeTopic.primary = 'false';
            nonPrimeTopic.topic = topic;
            console.log(nonPrimeTopic);
            discussionTopics.push(nonPrimeTopic);
        });

        let question = {};
        question.title = title;
        question.description = description;
        question.discussionTopicLinks = discussionTopics;
        console.log(question);
        toast.success('Question Posted Successfully!', {
            position: "top-center",
            autoClose: 3000
        });

        this.setState({ title: '',
                        description: '' });
    }

    onFilter = (event) => {
        console.log(event.target.value)
        console.log('filter');
    }

    onSort = (event) => {
        console.log(event)
        console.log(this.state.sortBy);
        let discussions = [...this.state.discussions];
        let data= [];
        
        discussions.sort((a, b) => new Date(b.discussion.createdDate).getTime() - new Date(a.discussion.createdDate).getTime());
        data = discussions;
        console.log(data)
       
        // if(this.state.sortBy === 'recently added') {
        //     discussions.sort((a, b) => 
        //     new Date(a.discussion.createdDate).getTime() - new Date(b.discussion.createdDate).getTime());
            
        //     data = discussions;
        //       console.log('recently added')
        //       console.log(data);
        //       // api call for recently added
        // } else {
        //     console.log('recently commented')
        //     // api call for recently commented
        // }

        this.setState({[event.target.name] : event.target.value,
                       discussions: data
        })
    }

    onReply = () => {
        let comments = [...this.state.comments];
        let comment = comments[0].comment;
        let replyComment =  {comment} ;
        let reply = "'" + replyComment.comment  + "'";
        console.log(replyComment)
        console.log(reply.bold());
        let replyBold = reply.bold();
        this.setState({reply: reply})
    }

    onPostComment = () => {
        let comment = this.state.comment;
        let discussionId = this.state.selectedDiscussion.id;
        console.log(discussionId);
        console.log(comment); 
 
        toast.success('Comment added Successfully!', {
           position: "top-center",
           autoClose: 3000
        });
    }

    onFollowResponse = () => {
        let discussionId = this.state.selectedDiscussion.id;
        console.log(discussionId);
        console.log('id');
        let label = '';
        if(this.state.responseLabel === 'Following Response') {
            console.log('true');
            label = 'Follow Response'
        } 

        console.log(label);
        this.setState({responseLabel: label})
    }

    onFollowResponse = () => {
        let discussionId = this.state.selectedDiscussion.id;
        console.log(discussionId);
        console.log('id');
        let label = '';
        if(this.state.responseLabel === 'Following Response') {
            console.log('true');
            label = 'Follow Response'
        } 

        console.log(label);
        this.setState({responseLabel: label})
    }

    render() {
        console.log(this.state.responseLabel);
        return(
            <div className={classes.Forum}>
            {this.state.doLoadDiscussion ?
                <div>
                <div className={classes.searchHeader}>
                    <input type='text' 
                           className ={classes.searchBar} 
                           placeholder='Search for a question'
                           onKeyDown={this.onSearch} />
                    <div className={classes.or}>  or </div>
                    <div className={classes.askQuestionButton}>
                        <Button  variant="contained"
                                 color="primary"
                                 onClick={this.onAskQuestion}>
                            Ask a question
                        </Button>
                    </div>
                </div>
                <div className={classes.filterSort}>
                    <div className = {classes.sortBy}> 
                    <NativeSelect  value={this.state.sortBy}
                                   name='sortBy'
                                   onChange={this.onSort.bind(this)}>
                    <option value='recently commented'>Recently Commented</option>
                    <option value='recently added'>Recently added</option>
          
                    </NativeSelect>
                    </div>
                    <div className = {classes.followingFilter}>
                        <label >
                        <Checkbox value='following'
                                  onClick={this.onFilter}/>
                             Show which I follow 
                        </label> 
                    </div>
                    <div className = {classes.authorFilter}>
                        <label >
                        <Checkbox value='author' 
                                  onClick = {this.onFilter} /> 
                            Show which I am an author
                        </label>                                  
                    </div>
                </div>

                {/* <div className={classes.discussionCard}>  
                {this.state.discussions.map((discussion,index) =>
                    <Card className={classes.card}
                          key ={index}
                          onClick={() => this.onSelectDiscussion(discussion.discussion)}>
                    <CardContent> 
                        <div className={classes.title}>{discussion.discussion.title}</div>
                        <div className={classes.description}>{discussion.discussion.description}</div>
                    </CardContent>
                    </Card> )}
                </div> */}
                <div className = {classes.discussionCard}>
                    {this.state.discussions.length === 0 ? null : 
                    <Virtualize  data = {this.state.discussions} select = {this.onSelectDiscussion} />}
                </div>
                </div> : null }
           
            {this.state.doAskQuestion ? <Question cancel={this.onCancelQuestion}
                                                  post={this.onPostQuestion}
                                                  primeTopic = {this.state.primaryTopic}
                                                  secondTopic = {this.state.secondaryTopic}
                                                  questionTopics={this.state.topics}
                                                  inputChange={this.onChange.bind(this)}
                                                  questionTitle={this.state.title}
                                                  questionDescription = {this.state.description}
                                                  /> : null}

            {this.state.isDiscussionSelected ? <Discussion data={this.state.selectedDiscussion}
                                                           comment = {this.state.comments}
                                                           reply={() => this.onReply}
                                                           inputChange={this.onChange.bind(this)}
                                                           responseComment = {this.state.comment}
                                                           replyComment = {this.state.reply}
                                                           postComment = {this.onPostComment}
                                                           follow={this.onFollowResponse}
                                                           label = {this.state.responseLabel}
                                                           moveFocus = {this.onMoveFocus}/> : null}

            <div> <ToastContainer /> </div>
            </div>
        );
    }
}

export default Forum;