import React, {Component} from 'react';
import classes from './Forum.scss';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import { Checkbox } from '@material-ui/core';
import TextField from '@material-ui/core/TextField';
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Question from './Question/question.component';
import Discussion from './Discussion/discussion.component';

// import Virtualize from '../../../lib/search/virtulize/LandVirtualize.component'

/*
 * File: Forum.container.js
 * Project: land-react-ui
 * File Created: Wednesday, 20th March 2019 11:44:32 am
 * Author: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Last Modified: Thursday, 21st March 2019 7:37:42 pm
 * Modified By: suchithra.selvarajulu (suchithra.s@object-frontier.com)
 * -----
 * Copyright 2019 Object Frontier Software Pvt. Ltd
 */

class Forum extends Component {
    state = {
        doLoadDiscussion: true,
        discussions: [],
        comments: [],
        sortBy : '',
        doAskQuestion: false,
        isDiscussionSelected: false,
        title:'',
        description:'',
        reply: '',
        selectedDiscussion : {},
        comment: '',
        addDiscussion : {
            discussion: {
                title: '',
                description: '',
                discussionTopicLinks: ''
            },
            user: {
                id: ''
            }
        }
    }

    getComment = () => {
        let data = require('../../assets/comment.json');
        this.setState({comments : data});
    }

    componentDidMount = () => {
        this.getComment();
        let data = require('../../assets/discussion.json');
        this.setState({discussions : data});
        console.log(data)

    }

    onSearch = (event) => {
        let searchText = event.target.value;
        let discussions = [...this.state.discussions];
        let searchedDiscussion = [];
        discussions.filter( (discussion) => {
            let question = discussion.discussion.description.toLowerCase();
              if( (question.includes(searchText.toLowerCase())) || (question.startsWith(searchText.toLowerCase()))) {
                   searchedDiscussion.push(discussion); 
                   
                }
            });

            if(searchText === 0) {
                let allDiscussions = []
                this.setState({discussions: allDiscussions})
            } else {
                this.setState({discussions : searchedDiscussion}) 
            }

            console.log(searchedDiscussion); 
            // this.setState({discussions : searchedDiscussion}) 
             
            // if (searchText === 0) {
            //     let allDiscussions = discussions;
            //     this.setState({discussions: allDiscussions })
            // } else {
            //     this.setState({discussions: searchedDiscussion})
            // }
    }

    onSelectChange = (event) => {
        console.log(event.target.value)

    }

    onSelectDiscussion = (discussion) => {
        console.log(discussion);
        this.setState({ isDiscussionSelected : true,
                        doLoadDiscussion :false,
                        selectedDiscussion : discussion
                    })
        console.log(this.state.selectedDiscussion);            
    }

    onChange(event) {
        console.log(event.target.value)
        this.setState({[event.target.name]: event.target.value})
        console.log(title)
    }
    

    isEnabled = this.state.title> 0;

    onAskQuestion = () => {
        console.log('ask question');
        this.setState({doAskQuestion: true,
                       doLoadDiscussion: false})
    }

    onCancelQuestion = () => {
        console.log('cancel');
    }
    
    onPostQuestion = () => {
        this.setState({ title: '' });
        console.log('post');
    }

    onFilter = () => {
        let filter = event.target.value;
        console.log(filter);
         if (filter === 'following') {
             {this.state.discussions}
         }

    }

    onSort = (direction, sortBy) => {
        console.log('sorted')    
    }

    onReply = () => {
        let comments = [...this.state.comments];
        let comment = comments[0].comment;
        let replyComment =  {comment} ;
        let reply = "'" + replyComment.comment  + "'";
        console.log(replyComment)
        console.log(reply.bold());
        let replyBold = reply.bold();
        this.setState({reply: replyBold})
    }

    render() {
        console.log(this.state.comments);
        
        return(
            <div className={classes.Forum} >
            {this.state.doLoadDiscussion ? <div> <div className={classes.searchHeader}>
                                                    {/* <div > */}
                                                    <input type='text' className ={classes.searchBar} 
                                                                       placeholder='search for a discussion'
                                                                       onKeyDown={this.onSearch} />
                                                                        <span> or </span> 
                                                    <div className={classes.askQuestionButton}>
                                                    <Button  variant="contained" 
                                                             color="primary"
                                                             onClick={this.onAskQuestion}> Ask a Question</Button>
                                                    </div>
                                                    {/* </div> */}
                                                 </div>
                                                 <div className={classes.filterSort}>
                                                    <div className = {classes.sortBy}> 
                                                       <Select value='true'
                                                               onChange={this.onSelectChange}>
                                                           <MenuItem value='true' >Recently commented</MenuItem>
                                                           <MenuItem value='false'>Recently added</MenuItem>
                                                       </Select>
                                                    </div>
                                                    <div className={classes.filter}>
                                                        <div className = {classes.followingFilter}>
                                                            <label ><Checkbox value='following' onClick={this.onFilter}/> Show which I am following </label> 
                                                        </div>
                                                        <div className = {classes.authorFilter}>
                                                            <label ><Checkbox value='author'/> Show which I'm an author </label>                                  
                                                        </div>
                                                    </div>
                                                 </div>
                                                <div className={classes.discussionCard}>  
                                                    {this.state.discussions.map((discussion, index) =>
                                                                       <Card className={classes.card}
                                                                             key ={index}
                                                                             onClick={() => this.onSelectDiscussion(discussion.discussion)} >
                                                                           <CardContent> 
                                                                                <div className={classes.title}>
                                                                                    {discussion.discussion.title}
                                                                                </div>
                                                                                <div className={classes.description}>
                                                                                    {discussion.discussion.description}
                                                                                </div>
                                                                           </CardContent>
                                                                       </Card> 
                                                    )}
                                                 </div>
                                            </div> : null }

            {this.state.doAskQuestion ? <Question cancel={this.onCancelQuestion}
                                                  post={this.onPostQuestion}
                                                  inputChange={this.onChange}
                                                  questionTitle={this.state.title}
                                                  //  enablePost = {this.isEnabled}
                                                /> : null}

            {this.state.isDiscussionSelected ? <Discussion data={this.state.selectedDiscussion}
                                                           comment = {this.state.comments}
                                                           replyComment={this.state.reply}
                                                           reply={this.onReply}/> : null}

            {/* <Virtualize suggest={this.state.discussions}  />                                                            */}

                     
           </div>
        );
    }
}

export default Forum;
