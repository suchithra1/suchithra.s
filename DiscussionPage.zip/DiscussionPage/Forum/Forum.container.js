import React, {Component} from 'react';
import classes from './Forum.scss';
import Button from '@material-ui/core/Button';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import { Checkbox } from '@material-ui/core';
import Select from "@material-ui/core/Select";
import MenuItem from "@material-ui/core/MenuItem";
import Question from './Question/question.component';
import Discussion from './Discussion/discussion.component';

// import Virtualize from '../../../lib/search/virtulize/LandVirtualize.component'



class Forum extends Component {
    state = {
        doLoadDiscussion: true,
        // discussions:[
        //     {'question' : 'why cant we use grid.length to get columns?',
        //      'comment' :'It is a two-dimensional-array, Each row can have its own length/number of columns'},
        //     {'question':'can we use another app for java'},{'question':'is java pure object oriented ?'},
        //     {'question':'java vs ktolin'},{'question':'Does Machine can inhert Info and IStartable interfaces ?'},
        //     {'question':'inheritance in oops'}],
        discussions: [],
        sortBy : '',
        doAskQuestion: false,
        isDiscussionSelected: false,
        title:'',
        description:'',
        selectedDiscussion : {},
        comment: ''

    }

    componentDidMount = () => {
        let data = require('../../assets/discussion.json');
        this.setState({discussions : data});
        console.log(data)
    }

    onSearch = (event) => {
        let searchText = event.target.value;
        let discussions = [...this.state.discussions];
        let searchedDiscussion = [];
        discussions.filter( (discussion) => {
            let question = discussion.question.toLowerCase();
              if( (question.includes(searchText.toLowerCase())) || (question.startsWith(searchText.toLowerCase()))) {
                   searchedDiscussion.push(discussion); 
                   
                }
            });

            if(searchText === null) {
                let allDiscussions = discussions;
                this.setState({discussions: allDiscussions})
            }

            console.log(searchedDiscussion); 
            this.setState({discussions : searchedDiscussion}) 
             
            // if (searchText) {
            //     this.setState({discussions: searchedDiscussion})
            // } else {
            //     let allDiscussions = discussions;
            //     this.setState({discussions: allDiscussions })
            // }
    }

    onSelectDiscussion = (discussion) => {
        console.log(discussion)
        // alert('clicked')
        this.setState({ isDiscussionSelected : true,
                        doLoadDiscussion :false
                        // selectedDiscussion : discussion
                    })
    }

    onChange(event) {
        this.setState({title: event.target.value})
    }
    

    isEnabled = this.state.title> 0;

    onAskQuestion = () => {
        console.log('ask question');
        this.setState({doAskQuestion: true,
                       doLoadDiscussion: false})
    }

    onCancelQuestion = () => {
        console.log('cancel');
    }
    
    onPostQuestion = () => {
        this.setState({ title: '' });
        console.log('post');
    }

    onFilter = (filter) => {
        console.log('filter');

    }

    onSort = (direction, sortBy) => {
        console.log('sorted')    
    }

    onReply = (discussion) => {
        // let data = JSON.stringify(discussion);
        console.log(discussion);

    }

    render() {
        console.log(this.state.discussions)
        
        return(
            <div className={classes.Forum} >
            {this.state.doLoadDiscussion ? <div> <div className={classes.searchHeader}>
                                                    <div >
                                                    <input type='text'  className ={classes.searchBar} 
                                                                     placeholder='Search for a question'
                                                                     onKeyDown={this.onSearch} />
                                                                         or
                                                    <div className={classes.askQuestionButton}>
                                                    <Button  variant="contained" 
                                                             color="primary"
                                                             onClick={this.onAskQuestion}> Ask a Question</Button>
                                                    </div>
                                                    </div>
                                                 </div>
                                                 <div className={classes.filterSort}>
                                                    <div className = {classes.sortBy}> 
                                                       <Select value='true'
                                                               onChange={this.onSort}>
                                                           <MenuItem value='true' >Recently commented</MenuItem>
                                                           <MenuItem value='false'>Recently added</MenuItem>
                                                       </Select>
                                                    </div>
                                                    <div className = {classes.followingFilter}>
                                                        <label ><Checkbox value='following'/> Show discussions I am following </label> 
                                                    </div>
                                                    <div className = {classes.authorFilter}>
                                                        <label ><Checkbox value='author'/> Show discussions I added </label>                                  
                                                    </div>
                                                 </div>
                                                 <div className={classes.discussionCard}>  
                                                    {this.state.discussions.map((discussion, index) =>
                                                                       <Card className={classes.card}
                                                                             key ={index}
                                                                             onClick={this.onSelectDiscussion}>
                                                                           <CardContent> {discussion.title}</CardContent>
                                                                           <CardActions onClick={this.onSelectDiscussion.bind(this, discussion)}/>
                                                                       </Card> 
                                                    )}
                                                 </div>
                                            </div> : null }

            {this.state.doAskQuestion ? <Question cancel={this.onCancelQuestion}
                                                  post={this.onPostQuestion}
                                                  inputChange={this.onChange}
                                                  questionTitle={this.state.title}
                                                  //  enablePost = {this.isEnabled}
                                                /> : null}

            {this.state.isDiscussionSelected ? <Discussion data={this.state.discussions}
                                                           reply={this.onReply}/> : null}

            {/* <Virtualize suggest={this.state.discussions}  />                                                            */}

                     
           </div>
        );
    }
}

export default Forum;
