import React from 'react';
import Chip from '@material-ui/core/Chip';
import FaceIcon from '@material-ui/icons/Face';
import { withStyles } from '@material-ui/core/styles';

import Aux from '../../../lib/hoc/landAux.component';
import * as appConstants from '../AddCourse.constants';

/*
 * Created Date: Monday, February 25th 2019, 9:23:08 pm
 * Author: shahul.shaik
 * 
 */

const styles = theme => ({
    chip: {
      margin: theme.spacing.unit - 5,
    },
});

const author = (props) => {
    const classes = props.classes;
    return props.authors.map((author, index) => {
        return (
            <Aux key={index} className={appConstants.AUTHOR_COMPONENT}>
                <Chip
                  icon={<FaceIcon/>}
                  label={author.first_name +  appConstants.VALUE + author.last_name}
                  onDelete={() => props.remove(author)}
                  className={classes.chip} />
            </Aux>
        );
    });
};

export default withStyles(styles)(author);