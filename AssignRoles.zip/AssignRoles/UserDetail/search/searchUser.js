import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import InputBase from '@material-ui/core/InputBase';
import SearchIcon from '@material-ui/icons/Search';

const searchUser = ( props ) => {
    const { classes } = props;
    let error = props.searchValidate ? <label className = { classes.searchError }>{props.errorMessage}</label> : null
    return (
        <div className = { classes.root }>
            <AppBar position = 'relative'>
                <Toolbar>
                    <div className = { classes.search }>
                        <div className = { classes.searchIcon }>
                            <SearchIcon />
                        </div>
                            <InputBase
                                placeholder = 'Search for user'
                                classes = { {
                                    root: classes.inputRoot,
                                    input: classes.inputInput,
                                } }
                                onKeyUp = { ( event ) => props.searching ( event.target.value, event.keyCode ) }
                            />
                    </div>
                </Toolbar>
                { error }
            </AppBar>
        </div>
    );
}

export default searchUser;
