import React from 'react';
import expect from 'expect';
import { shallow, mount } from 'enzyme';
import RoleDetail from './roleDetail.component';
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import { configure } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { Checkbox } from '@material-ui/core';

configure({ adapter: new Adapter() });

describe('RoleDetail', () => {
    const props = {
        role: [
          {
            classes: []
          }
        ],
        buttonLabel: 'Courses',
    }

    it('should render roleDetail without crashing', () => {
        const wrapper = shallow(<RoleDetail role={['trainer', 'author', 'evaluator']}  role={props.role} />);
        expect(wrapper.find('h2').text()).toEqual('ASSIGN ROLES');
    });

    it('should contain ReactMultiSelect component', () => {
        const wrapper = mount(<RoleDetail role={props.role} />);
        expect(wrapper.find(<ReactMultiSelectCheckboxes placeholderButtonLabel={props.buttonLabel}/>)).toBeTruthy;
    });
    
    it('should display courses if no course is selected' , () => {
        const wrapper = mount(<RoleDetail placeholderButtonLabel='Courses'
                             role={props.role} />);
        const reactMultiSelect = wrapper.find(<ReactMultiSelectCheckboxes />);
        expect(reactMultiSelect.find('placeholderButtonLabel').text()).toEqual('Courses');
    });

    it('should invoke handleSelectRole() on selecting a role', () => {
        let roleClicked = jest.fn();
        const wrapper = shallow(<RoleDetail role={props.role} />);
        wrapper.find(Checkbox).simulate('onChange');
        expect(roleClicked).toHaveBeenCalled();
    })

    it('should render submit button', () => {
        const roleClicked = jest.fn();
        const wrapper = shallow(<RoleDetail role={props.role} roleClicked={roleClicked} />);
        const button = wrapper.find('#submit');
        expect(button.length).toBe(1);
        button.simulate('click');
    });
});
