import React from 'react';
import ReactMultiSelectCheckboxes from 'react-multiselect-checkboxes';
import { Checkbox } from '@material-ui/core';
import classes from './roleDetail.scss';
import * as constants from './roleDetail.constants';

const roleDetail = (props) => {
 
    let displayRoles = [];
    props.role.map((roleToDisplay, index) => {

        roleToDisplay.classes.push(classes.roleLabel);

        if (roleToDisplay.hasCourse === constants.HAS_COURSE_TRUE) {
            displayRoles.push( <div>
                               <label className = {roleToDisplay.classes.join(' ')} >
                                    {roleToDisplay.name}
                               </label>
                               <div className = {classes.course}>
                               <ReactMultiSelectCheckboxes id = {constants.MULTISELECT}
                                                           placeholder = {constants.SEARCH_COURSE}
                                                           placeholderButtonLabel = {constants.COURSES}
                                                           minWidth = {constants.MIN_WIDTH}
                                                           options = {props.courses}
                                                           name = {roleToDisplay.name}
                                                           id = {roleToDisplay.id}
                                                           key = {index}
                                                           onChange = {props.courseSelected} />
                               </div>
                               </div>)
        } else {
            displayRoles.push(  <div>
                                <label className = {roleToDisplay.classes.join(' ')} >
                                    {roleToDisplay.name}
                                </label>
                                <div className = {classes.checkbox}>
                                      <Checkbox id= {constants.SELECT_ROLE}
                                                name = {roleToDisplay.name} 
                                                onChange = {props.roleSelected} 
                                                key = {index}
                                                defaultChecked={false} /> 

                                </div>
                                </div>)
       }
    })
    
    return (
        <div id={constants.ROLE_DETAIL} className={classes.roleDetail} >
            <div className={classes.heading}>
                <h2>ASSIGN ROLES</h2>
            </div>
            <div className={classes.innerWrapper}> 
                {/* <div> */}
                    {displayRoles}
                {/* </div> */}
            </div>
            <div className={classes.submit}>
                <button id= {constants.SUBMIT} onClick={props.submitClicked}>SUBMIT</button>
            </div>
        </div>

    );
}

export default roleDetail;
