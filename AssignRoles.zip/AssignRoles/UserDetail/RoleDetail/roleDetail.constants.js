export const SEARCH_COURSE = 'Search Courses';
export const COURSES = 'Courses';
export const MIN_WIDTH = '130px';
export const SELECT_ROLE = 'selectRole';
export const SUBMIT = 'submit';
export const ROLE_DETAIL = 'roleDetail';
export const HAS_COURSE_TRUE = 'true';
export const MULTISELECT = 'multiSelect';