import React from 'react';
import Icon from '@material-ui/core/Icon';

const Icons =  (props) => {
    let iconButton = null;
    if (props.toggle) {
        iconButton = <Icon id = { props.key } 
                            color = 'disabled'
                            onClick = { props.handleToggle }>remove_circle</Icon>
    } else {
        iconButton = <Icon id = { props.key } 
                            color = 'secondary' 
                            onClick = { props.handleToggle }>add_circle</Icon>
    }
    return (
        <div>
            <div>
                { iconButton }
                <Icon id = { props.key } 
                    color = 'error' 
                    onClick = { props.deleteCourse }>delete</Icon>
            </div>
        </div>
    );
}

export default Icons;
