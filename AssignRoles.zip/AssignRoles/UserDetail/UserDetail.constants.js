export const REGEX_SPCL_CHAR_WITHOUT_COMMA = /[ !@#$%^&*()_+\-[\]{};':'\\|.<>/?= ]/;
export const REGEX_SPCL_CHAR = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/;

export const ERR_MSG = {
    INPUT_ERR_MSG: 'please enter valid input',
    TEXT_LENGTH_ERR: 'Only 40 characters allowed',
    MAX_CHAR_ERR: 'no special characters allowed'
};

export const HEADER = {
    ID: 'ID',
    FIRST_NAME: 'FIRST NAME',
    LAST_NAME: 'LAST NAME',
    TRAINER: 'TRAINER',
    EVALUATOR: 'EVALUATOR',
    AUTHOR: 'AUTHOR',
    MISC: 'MISC'
};

export const DATAKEY = {
    ID: 'id',
    FIRSTNAME: 'firstName',
    LASTNAME: 'lastName',
    TRAINER: 'Trainer',
    EVALUATOR: 'Evaluator',
    AUTHOR: 'Author',
    MISC: 'Misc'
};

export const CHECKED_LIST = 'checkedList';

export const SUCCESS_MESSAGE = 'Role Assigned Successfully';
export const TOP_CENTER = 'top-center';
export const ERROR_MESSAGE = 'Please select a role and (or) course';
