import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import TableCell from '@material-ui/core/TableCell';
import { AutoSizer, Column, Table } from 'react-virtualized';
import Checkbox from '@material-ui/core/Checkbox';
import Icons from '../icons/icons';
import Styles from '../styles/styles';

class MuiVirtualizedTable extends React.PureComponent {

    getRowClassName = ({index}) => {
        
        const {classes, rowClassName}  = this.props;
        return classNames(classes.tableRow, classes.flexContainer, rowClassName, {
            [classes.tableRowHover]: index !== -1 
        } );
    };

    cellRenderer = ({cellData, columnIndex = null}) => {
        
        const {columns, classes, rowHeight, onRowClick} = this.props;
        let cellInfo = [];
        if (cellData) {
            if (columnIndex === 0) {
                let toggleSelect = this.props.isAllSelected ? this.props.isAllSelected : cellData.selected
                cellInfo.push( 
                    <Checkbox checked = {toggleSelect} onClick = {() => this.props.toggleSelect(cellData.userId)}/> 
                );
            }
        }
        this.cellDataRenderer(cellData, columnIndex, columns, cellInfo);
        return (
            <TableCell
                component = 'div'
                className = {classNames(classes.tableCell, classes.flexContainer, {
                    [ classes.noClick ]: onRowClick == null,
                })}
                variant = 'body'
                style = {{height: rowHeight}}
            >
                { cellInfo }
            </TableCell>
        );
    };

    cellDataRenderer = (cellData, columnIndex, columns, cellInfo) => {
        const { classes } = this.props;
        if (typeof cellData === 'object' && columnIndex !== 0) {
            cellData.map(data => {
                cellInfo.push(
                    <div className = {classes.courses}>
                        { data.name }
                        <Icons 
                            handleToggle  = {() => this.props.handleToggle(columns[columnIndex].dataKey, data.userId, data.name)} 
                            toggle = {data.isActive} 
                            deleteCourse = {() => this.props.handleDeleteCourse( columns[columnIndex].dataKey, data.userId, data.name)}
                        />
                    </div>
                );
            } );
        }
        
        if (columnIndex !== 0 && typeof cellData !== 'object') {
            cellInfo.push(cellData);
        }
    }

    headerRenderer = ({ label }) => {
        const { headerHeight, classes } = this.props;
        const inner =
            <div>
                { label }
            </div>

        return (
            <TableCell
                component = 'div'
                className = { classNames(classes.tableCell, classes.flexContainer, classes.noClick) }
                variant = 'head'
                style = {{ height: headerHeight }} 
            >
                { inner }
            </TableCell>
        );
    };

    render() {
        const { classes, columns, ...tableProps } = this.props;
        
        return (
            <AutoSizer>
                { ({ height, width }) => (
                    <Table
                        className = { classes.table }
                        height = { height }
                        width = { width }
                        { ...tableProps }
                        rowClassName = { this.getRowClassName }
                    >
                        { columns.map( ( { cellContentRenderer = null, className, dataKey, ...other }, index ) => {
                            let renderer;
                            if ( cellContentRenderer != null ) {
                                renderer = cellRendererProps => {
                                    this.cellRenderer( {
                                        cellData: cellContentRenderer( cellRendererProps ),
                                        columnIndex: index,
                                    } );
                                }
                            } else {
                                renderer = this.cellRenderer;
                            }

                            return (
                                <Column
                                    key = { dataKey }
                                    headerRenderer = {headerProps => 
                                        this.headerRenderer({
                                            ...headerProps,
                                            columnIndex: index,
                                        })
                                    }
                                    className = { classNames( classes.flexContainer, className ) }
                                    cellRenderer = { renderer }
                                    dataKey = { dataKey }
                                    { ...other }
                                />
                            );
                        } ) }
                    </Table>
                ) }
            </AutoSizer>
        );
    }
}


MuiVirtualizedTable.propTypes = {
    classes: PropTypes.object.isRequired,
    columns: PropTypes.arrayOf(
        PropTypes.shape( {
        cellContentRenderer: PropTypes.func,
        dataKey: PropTypes.string.isRequired,
        width: PropTypes.number.isRequired,
        } ),
    ).isRequired,
    headerHeight: PropTypes.number,
    onRowClick: PropTypes.func,
    rowClassName: PropTypes.string,
    rowHeight: PropTypes.oneOfType( [ PropTypes.number, PropTypes.func ] ),
};

MuiVirtualizedTable.defaultProps = {
    headerHeight: 56,
    rowHeight: 75,
};

const WrappedVirtualizedTable = withStyles( Styles )( MuiVirtualizedTable );

export default WrappedVirtualizedTable;
